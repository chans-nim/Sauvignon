"""섹터(또는 종목 그룹) 평가 지표: coherence, breadth, persistence, concentration."""

from __future__ import annotations

from typing import Sequence

import numpy as np
import pandas as pd


def _subset_returns(returns: pd.DataFrame, members: Sequence[str]) -> pd.DataFrame:
    cols = [c for c in members if c in returns.columns]
    if not cols:
        return pd.DataFrame()
    return returns[cols].dropna(how="all", axis=0)


def calc_coherence(returns: pd.DataFrame, members: Sequence[str]) -> float:
    """
    종목 간 수익률 상관의 평균(절댓값) — 높을수록 동조화.
    """
    sub = _subset_returns(returns, members)
    if sub.shape[1] < 2 or len(sub) < 5:
        return 0.0
    corr = sub.corr(numeric_only=True)
    if corr.empty:
        return 0.0
    v = corr.values
    tri = v[np.triu_indices_from(v, k=1)]
    tri = tri[~np.isnan(tri)]
    if tri.size == 0:
        return 0.0
    return float(np.clip(np.mean(np.abs(tri)), 0.0, 1.0))


def calc_breadth(returns: pd.DataFrame, members: Sequence[str], *, last_n: int = 1) -> float:
    """
    최근 ``last_n``일 중 마지막 날 기준 상승 종목 비율 (0~1).
    """
    sub = _subset_returns(returns, members)
    if sub.empty:
        return 0.0
    tail = sub.iloc[-last_n:]
    last = tail.iloc[-1]
    up = (last > 0).sum()
    tot = last.notna().sum()
    if tot <= 0:
        return 0.0
    return float(np.clip(up / float(tot), 0.0, 1.0))


def calc_persistence(returns: pd.DataFrame, members: Sequence[str]) -> float:
    """
    일별 그룹 평균 수익이 양수인 날 비율 (0~1).
    """
    sub = _subset_returns(returns, members)
    if sub.empty or len(sub) < 3:
        return 0.0
    daily = sub.mean(axis=1, skipna=True)
    pos = (daily > 0).sum()
    tot = daily.notna().sum()
    if tot <= 0:
        return 0.0
    return float(np.clip(pos / float(tot), 0.0, 1.0))


def calc_concentration(returns: pd.DataFrame, members: Sequence[str]) -> float:
    """
    특정 종목 쏠림: 마지막 일 |수익률| 비중의 Herfindahl (0~1, 높을수록 쏠림).
    """
    sub = _subset_returns(returns, members)
    if sub.empty:
        return 0.0
    last = sub.iloc[-1].astype(float)
    last = last[np.isfinite(last)]
    if last.empty:
        return 0.0
    w = np.abs(last.values)
    s = float(w.sum())
    if s <= 1e-12:
        return 0.0
    p = w / s
    h = float(np.sum(p**2))
    return float(np.clip(h, 0.0, 1.0))


def calc_relative_return(returns: pd.DataFrame, members: Sequence[str]) -> float:
    """최근 5일 누적 중앙 수익률을 0~1로 클리핑 정규화 근사."""
    sub = _subset_returns(returns, members)
    if sub.empty:
        return 0.0
    tail = sub.iloc[-min(5, len(sub)) :]
    med = float(np.nanmedian(tail.mean(axis=1).values))
    return float(np.clip(0.5 + med * 30.0, 0.0, 1.0))
